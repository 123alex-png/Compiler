# irsim written in python2

decompiled from official \*.pyc

```
sudo pip install uncompyle6
uncompyle6 irsim.pyc > irsim.py
uncompyle6 ui_mainwindow.pyc > ui_mainwindow.py
uncompyle6 resources_rc.pyc > resources_rc.py
```
